export const environment = {
  production: false,
  APIS_URL: 'http://localhost/aca_apis/'
};
